package com.bjlemon.springboot.service;

import org.springframework.security.core.userdetails.UserDetailsService;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName UserService.java
 * @Description TODO
 * @createTime 2020年02月18日 20:43:00
 */
public interface UserService extends UserDetailsService {
}
