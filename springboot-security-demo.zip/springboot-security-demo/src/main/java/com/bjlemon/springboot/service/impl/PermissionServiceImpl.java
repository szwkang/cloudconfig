package com.bjlemon.springboot.service.impl;

import com.bjlemon.springboot.service.PermissionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName PermissionServiceImpl.java
 * @Description TODO
 * @createTime 2020年02月18日 20:44:00
 */
@Service
@Transactional
public class PermissionServiceImpl implements PermissionService {

}
