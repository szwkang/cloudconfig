package com.dongnao.nacos.controller;

import com.dongnao.nacos.client.ProviderClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConsumerController {

    @Autowired
    private ProviderClient providerClient;

    @GetMapping("/service")
    public String service() {
        String result = this.providerClient.service();
        return "服务调用方调用了方法，结果为:" + result;
    }
}
