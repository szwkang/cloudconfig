package com.dongnao.nacos.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient("nacos-prodiver")
public interface ProviderClient {

    @GetMapping("/service")
    String service();
}
