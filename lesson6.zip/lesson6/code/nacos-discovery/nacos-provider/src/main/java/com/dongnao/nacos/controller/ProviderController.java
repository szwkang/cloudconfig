package com.dongnao.nacos.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@ConfigurationProperties(prefix = "server")
public class ProviderController {

    private String port;

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    @GetMapping("/service")
    public String service() {
        log.info("服务提供者提供了服务，其端口为" + this.port);
        return "Helloworld Nacos";
    }

}
