package com.dongnao.annotation;

public class MyAnnotationDemoTest {

    public static void main(String[] args) {

        if (MyAnnotationDemo.class.isAnnotationPresent(MyAnnotation.class)) {
            MyAnnotation annotation = MyAnnotationDemo.class.getAnnotation(MyAnnotation.class);
            System.out.println(annotation.name());
        }
    }
}
