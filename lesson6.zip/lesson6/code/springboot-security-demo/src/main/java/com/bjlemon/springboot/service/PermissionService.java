package com.bjlemon.springboot.service;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName PermissionService.java
 * @Description TODO
 * @createTime 2020年02月18日 20:43:00
 */
public interface PermissionService {
}
