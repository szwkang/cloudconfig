package com.dongnao.spring.ioc.test;

import com.dongnao.spring.config.UserConfig;
import com.dongnao.spring.domain.User;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName UserTest.java
 * @Description TODO
 * @createTime 2020年03月06日 20:37:00
 */
public class UserTest {

    private ApplicationContext context;
    private User user;

    @Before
    public void setUp() {
        this.context = new AnnotationConfigApplicationContext(UserConfig.class);
        this.user = this.context.getBean(User.class);
    }

    @Test
    public void test1() {
        System.out.println(this.user);

        // TODO User类型的对象纳入到容器
        String[] beanDefinitionNames = this.context.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames) {
            System.out.println(beanDefinitionName);
        }

        System.out.println("---------------------------");

        String[] beanNamesForType = this.context.getBeanNamesForType(User.class);
        for (String beanNameTypeName : beanNamesForType) {
            System.out.println(beanNameTypeName);
        }

    }
}
