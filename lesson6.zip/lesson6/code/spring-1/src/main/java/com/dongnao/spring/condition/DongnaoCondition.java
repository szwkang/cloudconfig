package com.dongnao.spring.condition;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DongnaoCondition.java
 * @Description TODO
 * @createTime 2020年03月06日 21:05:00
 */
public class DongnaoCondition implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        // Windows 7
        String osName = context.getEnvironment().getProperty("os.name");
        if ("Windows 7".equalsIgnoreCase(osName)) {
            return true;
        }
        return false;
    }
}
