package com.dongnao.spring.selector;

import org.springframework.context.annotation.ImportSelector;
import org.springframework.core.type.AnnotationMetadata;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DongnaoImportSelector.java
 * @Description TODO
 * @createTime 2020年03月06日 21:21:00
 */
public class DongnaoImportSelector implements ImportSelector {

    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        return new String[]{
//                "com.dongnao.spring.domain.Privilege",
                "com.dongnao.spring.domain.Role"
        };
    }
}
