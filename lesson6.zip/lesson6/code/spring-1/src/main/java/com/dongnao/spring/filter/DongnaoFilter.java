package com.dongnao.spring.filter;

import org.springframework.core.type.ClassMetadata;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.core.type.filter.TypeFilter;

import java.io.IOException;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DongnaoFilter.java
 * @Description TODO
 * @createTime 2020年03月06日 20:51:00
 */
public class DongnaoFilter implements TypeFilter {

    @Override
    public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory) throws IOException {
//        AnnotationMetadata annotationMetadata = metadataReader.getAnnotationMetadata();
        ClassMetadata classMetadata = metadataReader.getClassMetadata();
        String className = classMetadata.getClassName();

        if (className.contains("Person")) {
            return true;
        }

        return false;
    }
}
