package com.dongnao.annotation;

@MyAnnotation(name = "myAnnotationDemo")
public class MyAnnotationDemo {

}
