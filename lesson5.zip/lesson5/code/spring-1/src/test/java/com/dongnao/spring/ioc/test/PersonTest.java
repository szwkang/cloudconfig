package com.dongnao.spring.ioc.test;

import com.dongnao.spring.config.PersonConfig;
import com.dongnao.spring.domain.Person;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName PersonTest.java
 * @Description TODO
 * @createTime 2020年03月06日 20:37:00
 */
@ContextConfiguration(classes = PersonConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class PersonTest {

    @Autowired
    private Person person;

    @Autowired
    private ApplicationContext context;

    @Test
    public void test1() {
        System.out.println(this.person);

        // TODO Person类型的对象纳入到容器
        String[] beanDefinitionNames = this.context.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames) {
            System.out.println(beanDefinitionName);
        }

        System.out.println("---------------------------");

        String[] beanNamesForType = this.context.getBeanNamesForType(Person.class);
        for (String beanNameTypeName : beanNamesForType) {
            System.out.println(beanNameTypeName);
        }

    }
}
