package com.dongnao.spring.ioc.test;

import com.dongnao.spring.config.RoleConfig;
import com.dongnao.spring.domain.Role;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName RoleTest.java
 * @Description TODO
 * @createTime 2020年03月06日 20:37:00
 */
@ContextConfiguration(classes = RoleConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class RoleTest {

    @Autowired
    private Role role;

    @Autowired
    private ApplicationContext context;

    @Test
    public void test1() {
        System.out.println(this.role);

        System.out.println("-----------------------");

        String[] beanDefinitionNames = this.context.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames) {
            System.out.println(beanDefinitionName);
        }
    }
}
