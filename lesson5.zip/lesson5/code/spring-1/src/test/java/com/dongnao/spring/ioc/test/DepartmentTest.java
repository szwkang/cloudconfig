package com.dongnao.spring.ioc.test;

import com.dongnao.spring.config.DepartmentConfig;
import com.dongnao.spring.domain.Department;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DepartmentTest.java
 * @Description TODO
 * @createTime 2020年03月06日 20:37:00
 */
@ContextConfiguration(classes = DepartmentConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class DepartmentTest {

    @Autowired
    private Department department;

    @Test
    public void test1() {
        System.out.println(this.department);
    }
}
