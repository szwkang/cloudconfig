package com.dongnao.spring.config;

import com.dongnao.spring.domain.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName UserConfig.java
 * @Description TODO
 * @createTime 2020年03月06日 20:36:00
 */
@Configuration
public class UserConfig {

    @Bean(name = {"u", "小puu"})
    public User user() {
        User user = User.builder().id(1000)
                .name("zhangsan")
                .password("admin")
                .salary(12.34F)
                .birthday(new Date())
                .build();
        return user;
    }
}
