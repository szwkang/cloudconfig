package com.dongnao.spring.config;

import com.dongnao.spring.domain.Person;
import com.dongnao.spring.filter.DongnaoFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;

import java.util.Date;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName PersonConfig.java
 * @Description TODO
 * @createTime 2020年03月06日 20:49:00
 */
@ComponentScan(value = "com.dongnao.spring.domain", includeFilters = {
        @ComponentScan.Filter(classes = DongnaoFilter.class, type = FilterType.CUSTOM)
})
public class PersonConfig {

    @Bean
    public Person person() {
        Person person = Person.builder().id(1000)
                .name("zhangsan")
                .password("admin")
                .salary(12.34F)
                .birthday(new Date())
                .build();
        return person;
    }
}
