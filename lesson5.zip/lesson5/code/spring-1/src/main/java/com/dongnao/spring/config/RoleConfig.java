package com.dongnao.spring.config;

import com.dongnao.spring.domain.Role;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName RoleConfig.java
 * @Description TODO
 * @createTime 2020年03月06日 21:14:00
 */
@Configuration
@Import(value = Role.class)
public class RoleConfig {


}
