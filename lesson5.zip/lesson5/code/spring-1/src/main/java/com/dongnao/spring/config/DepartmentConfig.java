package com.dongnao.spring.config;

import com.dongnao.spring.condition.DongnaoCondition;
import com.dongnao.spring.domain.Department;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DepartmentConfig.java
 * @Description TODO
 * @createTime 2020年03月06日 21:06:00
 */
@Configuration
public class DepartmentConfig {

    @Bean
    @Conditional(value = DongnaoCondition.class)
    public Department department() {
        Department department = new Department();
        department.setId(1);
        department.setName("IBM");
        department.setLocation("LOS");
        return department;
    }

}
