package com.dongnao.spring.config;

import com.dongnao.spring.registar.DongnaoBeanDefinitionRegistrar;
import com.dongnao.spring.selector.DongnaoImportSelector;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName PrivilegeConfig.java
 * @Description TODO
 * @createTime 2020年03月06日 21:24:00
 */
@Configuration
@Import(value = {DongnaoImportSelector.class, DongnaoBeanDefinitionRegistrar.class})
public class PrivilegeConfig {


}
