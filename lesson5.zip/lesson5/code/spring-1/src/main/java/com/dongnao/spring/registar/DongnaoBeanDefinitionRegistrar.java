package com.dongnao.spring.registar;

import com.dongnao.spring.domain.Privilege;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanNameGenerator;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.context.annotation.ImportBeanDefinitionRegistrar;
import org.springframework.core.type.AnnotationMetadata;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DongnaoBeanDefinitionRegistrar.java
 * @Description TODO
 * @createTime 2020年03月06日 21:31:00
 */
public class DongnaoBeanDefinitionRegistrar implements ImportBeanDefinitionRegistrar {

    @Override
    public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata,
                                        BeanDefinitionRegistry registry,
                                        BeanNameGenerator importBeanNameGenerator) {
        RootBeanDefinition rootBeanDefinition = new RootBeanDefinition(Privilege.class);
        registry.registerBeanDefinition("permission", rootBeanDefinition);
    }
}
