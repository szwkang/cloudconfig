package com.dongnao.springcloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudEurekaConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}
