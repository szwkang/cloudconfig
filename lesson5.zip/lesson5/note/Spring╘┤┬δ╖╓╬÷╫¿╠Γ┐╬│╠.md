# Spring 5.x源码分析专题课程

## 1. Spring IoC专题

## 1.1 容器的概念

- **AnnotationContextApplicationContext**
- ClassPathXmlApplicationContext

## 1.2 组件添加技术

- @ComponentScan
- @Bean
- @Configuration
- @Component
- @Service
- @Controller
- @Repository
- @Primary
- @Lazy
- @Scope
- @Conditional
- @Import
- ImportSelector接口
- FactoryBean接口

## 1.3 Bean的生命周期

- 初始化状态（init-method）
- 销毁状态（destroy-method）
- @PostConstruct
- @PreDestroy
- 实现相关接口（InitializingBean和DisposableBean）
- BeanPostProcessor

## 1.4 组件赋值

- @Value
- @PropertySource

## 1.5 组件注入（DI）

- 构造注入
- setter注入
- ApplicationContextAware--->ApplicationContextAwareProcessor

## 1.6 后置处理器

- BeanDefinitionRegistryPostProcessor源码分析

## 1.7 手写IoC



# 一. Spring概述

- Spring Framework
- Spring Boot
- Spring Cloud
- Spring Data
- Spring Security
- Spring Session
- Spring Batch
- ...



# 二.Bean如何纳入Spring容器

## 2.1 Java Config(Java配置方式的开发 注解编程)

- 利用@Configuration和@Bean

```java
package com.dongnao.spring.config;

import com.dongnao.spring.domain.User;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName UserConfig.java
 * @Description TODO
 * @createTime 2020年03月06日 20:36:00
 */
@Configuration
public class UserConfig {

    @Bean(name = {"u", "小puu"})
    public User user() {
        User user = User.builder().id(1000)
                .name("zhangsan")
                .password("admin")
                .salary(12.34F)
                .birthday(new Date())
                .build();
        return user;
    }
}

```

```java
package com.dongnao.spring.ioc.test;

import com.dongnao.spring.config.UserConfig;
import com.dongnao.spring.domain.User;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName UserTest.java
 * @Description TODO
 * @createTime 2020年03月06日 20:37:00
 */
@ContextConfiguration(classes = UserConfig.class)
@RunWith(SpringJUnit4ClassRunner.class)
public class UserTest1 {

    @Autowired
    private User user;

    @Autowired
    private ApplicationContext context;

    @Test
    public void test1() {
        System.out.println(this.user);

        // TODO User类型的对象纳入到容器
        String[] beanDefinitionNames = this.context.getBeanDefinitionNames();
        for (String beanDefinitionName : beanDefinitionNames) {
            System.out.println(beanDefinitionName);
        }

        System.out.println("---------------------------");

        String[] beanNamesForType = this.context.getBeanNamesForType(User.class);
        for (String beanNameTypeName : beanNamesForType) {
            System.out.println(beanNameTypeName);
        }

    }
}

```



- @ComponentScan

```java
@ComponentScan(value = "com.dongnao.spring.domain", includeFilters = {
        @ComponentScan.Filter(classes = DongnaoFilter.class, type = FilterType.CUSTOM)
})
public class PersonConfig {

    @Bean
    public Person person() {
        Person person = Person.builder().id(1000)
                .name("zhangsan")
                .password("admin")
                .salary(12.34F)
                .birthday(new Date())
                .build();
        return person;
    }
}
```

```java
package com.dongnao.spring.filter;

import org.springframework.core.type.ClassMetadata;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.core.type.filter.TypeFilter;

import java.io.IOException;

/**
 * @author jeffzhou
 * @version 1.0.0
 * @ClassName DongnaoFilter.java
 * @Description TODO
 * @createTime 2020年03月06日 20:51:00
 */
public class DongnaoFilter implements TypeFilter {

    @Override
    public boolean match(MetadataReader metadataReader, MetadataReaderFactory metadataReaderFactory) throws IOException {
//        AnnotationMetadata annotationMetadata = metadataReader.getAnnotationMetadata();
        ClassMetadata classMetadata = metadataReader.getClassMetadata();
        String className = classMetadata.getClassName();

        if (className.contains("Person")) {
            return true;
        }

        return false;
    }
}

```



- @Contional注册Bean

```java
@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Conditional {
    Class<? extends Condition>[] value();
}

```

```java
@FunctionalInterface
public interface Condition {
    boolean matches(ConditionContext var1, AnnotatedTypeMetadata var2);
}
```



```java
@Configuration
public class DepartmentConfig {

    @Bean
    @Conditional(value = DongnaoCondition.class)
    public Department department() {
        Department department = new Department();
        department.setId(1);
        department.setName("IBM");
        department.setLocation("LOS");
        return department;
    }

}
```

```java
public class DongnaoCondition implements Condition {

    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        // Windows 7
        String osName = context.getEnvironment().getProperty("os.name");
        if ("Windows 7".equalsIgnoreCase(osName)) {
            return true;
        }
        return false;
    }
}
```



- @Import注册Bean
    - 自动注册组件，bean的名称是该类的全限定名称
    - 接口ImportSelector。返回需要导入到Spring容器中的组件的全类名的数组

```java
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Import {

	/**
	 * {@link Configuration @Configuration}, {@link ImportSelector},
	 * {@link ImportBeanDefinitionRegistrar}, or regular component classes to import.
	 */
	Class<?>[] value();

}
```

```java
@Configuration
@Import(value = Role.class)
public class RoleConfig {


}
```

```java
public interface ImportSelector {

	/**
	 * Select and return the names of which class(es) should be imported based on
	 * the {@link AnnotationMetadata} of the importing @{@link Configuration} class.
	 * @return the class names, or an empty array if none
	 */
	String[] selectImports(AnnotationMetadata importingClassMetadata);

	/**
	 * Return a predicate for excluding classes from the import candidates, to be
	 * transitively applied to all classes found through this selector's imports.
	 * <p>If this predicate returns {@code true} for a given fully-qualified
	 * class name, said class will not be considered as an imported configuration
	 * class, bypassing class file loading as well as metadata introspection.
	 * @return the filter predicate for fully-qualified candidate class names
	 * of transitively imported configuration classes, or {@code null} if none
	 * @since 5.2.4
	 */
	@Nullable
	default Predicate<String> getExclusionFilter() {
		return null;
	}

}

```

```java
@Configuration
@Import(value = DongnaoImportSelector.class)
public class PrivilegeConfig {


}
```

```java
public class DongnaoImportSelector implements ImportSelector {

    @Override
    public String[] selectImports(AnnotationMetadata importingClassMetadata) {
        return new String[]{
                "com.dongnao.spring.domain.Privilege",
                "com.dongnao.spring.domain.Role"
        };
    }
}

```

- 接口ImportBeanDefinitionRegistry

- FactoryBean



# 三.源码分析

## 3.1 AnnotationConfigApplicationContext

![image-20200306214203173](images/image-20200306214203173.png)

- postProcessBeanFactory()：BeanFactory完成工作后进行后置处理
- invokeBeanFactoryPostProcessors()：执行BeanFactoryPostProcessor中的方法
- registerBeanPostProcessor()：注册BeanPostProcessor
- finishBeanFactoryInitialization()：完成BeanFactory初始化























