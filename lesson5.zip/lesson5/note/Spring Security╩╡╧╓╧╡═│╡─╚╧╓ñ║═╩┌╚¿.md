

# Jeff老师

## 1. Borland Delphi C/S结构

排队上机 软盘 

## 2. Java 面向线程 IO 网络

## 3.Java程序员-->核心层--->团队（管理）--->架构师



技术至上

编程思想，编程意识

英语 音乐 U盘



北京 上海  15k--->25k---->35w---->50w

70w

点--->线--->面



# 一.权限管理系统

## 1.认证

- 登录验证

![image-20200313203408506](C:\Users\Administrator\AppData\Roaming\Typora\typora-user-images\image-20200313203408506.png)

## 2.授权

- 用户的权限的访问控制
- 多种实现方式
    - 基于角色的访问控制（粗粒度）
    - 基于资源的访问控制（细粒度）：基于功能 /user/add  /user/delete/1000

```


```



## 2.模型

![image-20200313204028538](images/image-20200313204028538.png)

# 二.SpringBoot + SpringSecurity



3个名额 

VIP 全程问答回复，学习计划 

薄弱项

# 技术层面

## 突出优势

## Spring全栈

## 分布式 微服务































































