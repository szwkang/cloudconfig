# Spring Cloud微服务架构深入剖析

## 1. 从系统架构设计谈起

- 系统架构演变说起

    - 单体应用
    - 垂直划分
    - 分布式架构
    - SOA架构
    - 微服务

- SOA vs Microservice

    |          |   SOA    | Microservice |
    | :------: | :------: | :----------: |
    | 组件粒度 |    大    |      小      |
    |  耦合度  |    松    |     更松     |
    |   架构   | 任何类型 | 专注交叉团队 |

- 主流的微服务框架
    - **Spring Cloud**
    - ServiceComb
    - ZeroC ICE：Corba

## 2. Spring Cloud整体架构详解

- 相关概念

    - 服务发现与注册
        - 注册中心（Zookeeper(协调管理框架)、Eureka、Consul、Nacos）
        - 发现：
    - 负载均衡
        - 服务器端负载均衡：Nginx
        - 客户端负载均衡：Ribbon

    - 熔断

        - 断路器（Circuit Breaker）

        ![image-20200311205859553](images/image-20200311205859553.png)

![image-20200311205238209](images/image-20200311205238209.png)

- 链路追踪
    - 整个的调用过程监控，进行日志分析以及性能的监控

- API网关

![image-20200311210402098](images/image-20200311210402098.png)

- Netflix整套生态（五大组件 五大神兽）
    - Eureka
        - 闭源
        - 内存限制
        - 调度单一
        - 集群伸缩性限制
    - Ribbon
    - Feign
    - Hystrix
    - Zuul
- Alibaba
    - Nacos
        - 100K
    - Sentinel
    - ...
- 原生或其他组件
    - Gateway
    - Config
    - Sluth/Zipkin
    - Consul
        - Service Mesh
        - 报错，排错很麻烦
        - 5K
    - Stream
    - Bus

![image-20200311211436477](images/image-20200311211436477.png)





























## 3. Spring Cloud Netflix全栈案例深入剖析

### 3.1 搭建Eureka Server































## 4. Spring Cloud服务发现与注册的未来-Spring Cloud Alibaba

- Nacos
- Sentinel
- RocketMQ
- Seata(分布式事务解决方案)：感觉在做本地事务



























