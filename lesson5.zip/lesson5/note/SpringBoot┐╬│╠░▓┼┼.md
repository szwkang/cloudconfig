# SpringBoot课程安排

## 1.Spring Boot课程架构

## 2.Spring Boot自动配置原理

## 3.Spring Boot启动器深入剖析



# 一.SpringBoo概述

## 1. SSM

- 配置太多
- 维护成本高

## 2. SpringBoot

- 0配置（Java Config 全注解开发）
- 注解（Annotation）
    - 给Java编译器来识别 元数据 ---> 执行底层的逻辑

# 二.Spring Boot入门程序



# 三.自动配置原理

## 3.1 原理

- Spring启动加载启动类（）

 ![image-20200309204859574](images/image-20200309204859574.png)

- 分析@SpringBootApplication注解

![image-20200309205021423](images/image-20200309205021423.png)

- @SpringBootConfiguratoin

  ![image-20200309205122682](images/image-20200309205122682.png)

- 其实该注解就是一个配置类（想当于配置文件（applicationContext.xml））
- @Configuration注解实际上也就是一个@Component(组件)

- @ComponentScan
    - 扫描加了以下注解的@Controller,@Service,@Repository,@Component对象，将这些对象纳入Spring容器中
- @EnableAutoConfiguration**

 ![image-20200309205713507](images/image-20200309205713507.png)

- @AutoConfigurationPackage
- AutoConfigurationImportSelector：给Spring容器导入相关的组件

![img](images/SNAGHTML8c4858.PNG)

上述代码中可以得知：扫描所有jar包路径下的META-INF/spring.factories，把扫描到的这些文件的内容包装成properties对象，从properties中获取EnableAutoConfiguration类，然后将其放入Spring容器中。而XxxAutoConfiguration对象就会进行自动配置

- 以RabbitAutoConfiguration为例

 ![image-20200309211913436](images/image-20200309211913436.png)

- @ConditionalOnClass()：判断当前项目有没有这个类

    - 这种注解实际上是@Conditional注解的派生注解

    ​      ![image-20200309213222532](images/image-20200309213222532.png)

- @EnableConfigurationProperties：启动指定类的ConfigurationProperties功能



# 总结

## 1.SpringBoot启动加载大量的自动配置类（默认）

## 2.给容器添加组件

- 自己编写配置类
- @Bean



# 四.自定义Starter

## 4.1 starter如何编写自动配置

```
@Configuration
@ConditionalOnXxx
@AutoConfiguraeAfter
@Bean
```

- 自定义启动器用来做依赖导入
- 专门写一个自动配置工程
- 启动器依赖自动配置工程
    - META-INF/spring.factories--->org.springframework.boot.autoconfigure.EnableAutoConfiguration=\
        com.prosay.starter.HelloServiceAutoConfiguration
    - 
- 规范：自定义启动器名称-spring-boot-starter     mybatis-spring-boot-starter































































































