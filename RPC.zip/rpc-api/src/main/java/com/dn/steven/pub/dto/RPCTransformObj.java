package com.dn.steven.pub.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
@Data
public class RPCTransformObj implements Serializable {

    private static final long serialVersionUID = -5030220487327723515L;

    private  String  classPath;

    private  String methodName;

    private  Object[] parmas;

}
