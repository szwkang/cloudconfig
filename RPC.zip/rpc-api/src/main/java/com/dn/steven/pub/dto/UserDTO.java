package com.dn.steven.pub.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
@Data
public class UserDTO implements Serializable {

    private static final long serialVersionUID = 2065419313750498765L;
    private String name;
    private int age;
    private String userID;
}
