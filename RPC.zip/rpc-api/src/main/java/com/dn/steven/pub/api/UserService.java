package com.dn.steven.pub.api;

import com.dn.steven.pub.dto.UserDTO;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
@ServiceMapped("com.dn.steven.pub.api.impl.UserServiceImpl")
public interface UserService {

    public UserDTO addUser(UserDTO userDTO);

}
