package com.dn.steven.pub.dispatch;

import com.dn.steven.pub.dto.RPCTransformObj;

import java.lang.reflect.Method;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class ServiceDispatch {

    /**
     * 服务的分发.
     * @param object
     * @return
     */
    public static Object dispatch(Object object){
        //  反射.
        //  你的调用的类的全路径..
        //  你要调用的方法
        //  方法调用过程中使用的参数
        RPCTransformObj  reqObj =(RPCTransformObj)object;
        String classpath = reqObj.getClassPath();
        String methodName = reqObj.getMethodName();
        Object[] params = reqObj.getParmas();
        Class[] types = new Class[params.length];
        for (int i = 0; i <params.length ; i++) {
            types[i]= params[i].getClass();
        }
        Object respObj =null;
        //反射的方法调用
        try {
            Class  clazz = Class.forName(classpath);
            Method method = clazz.getDeclaredMethod(methodName,types);
            respObj= method.invoke(clazz.newInstance(),params);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return respObj;
    }
}
