package com.dn.steven.pub;

import com.dn.steven.pub.net.BIOServer;

import java.io.IOException;

/**
 * Hello world!
 *
 */
public class BootStrap
{
    public static void main( String[] args ) throws IOException {

        BIOServer.startServer(8888);

    }
}
