package com.dn.steven.pub.net;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class BIOServer {

    private static ExecutorService executorService = Executors.newFixedThreadPool(100);

    /**
     * 启动服务
     * @param port
     */
    public static void startServer(int port) throws IOException {

        ServerSocket ss = new ServerSocket(port);

        while(true) {
            Socket socket = ss.accept(); //阻塞的等待客户端的连接..

            executorService.submit(new RPCThreadProcessor(socket));
        }

    }

}
