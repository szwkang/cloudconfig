package com.dn.steven.pub.net;

import com.dn.steven.pub.dispatch.ServiceDispatch;
import com.sun.xml.internal.bind.v2.model.annotation.RuntimeAnnotationReader;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class RPCThreadProcessor implements Runnable {


    private Socket socket;

    public  RPCThreadProcessor(Socket socket){
        this.socket= socket;
    }

    @Override
    public void run() {

        //真正流的处理..
        ObjectInputStream ois =null;
        ObjectOutputStream oos = null;

        try {
            ois = new ObjectInputStream(socket.getInputStream()) ;

            Object reqObj = ois.readObject();

            Object respObj = ServiceDispatch.dispatch(reqObj);

            oos = new ObjectOutputStream(socket.getOutputStream()) ;

            oos.writeObject(respObj);

            oos.flush();

        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(ois !=null){
                try {
                    ois.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(oos !=null){
                try {
                    oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }
}
