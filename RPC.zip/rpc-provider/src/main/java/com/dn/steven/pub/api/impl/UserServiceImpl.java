package com.dn.steven.pub.api.impl;

import com.dn.steven.pub.api.UserService;
import com.dn.steven.pub.dto.UserDTO;

import java.util.Random;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class UserServiceImpl implements UserService {

    @Override
    public UserDTO addUser(UserDTO userDTO) {
        System.out.println("in : "+userDTO);
        userDTO.setUserID(new Random().nextInt(1000000)+"");
        System.out.println("out : "+userDTO);
        return userDTO;
    }
}
