package com.dn.steven.pub.net;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class BIOClient {


    /**
     * 调用远方接口
     * @param host
     * @param port
     * @param obj
     * @return
     */
    public static Object callRemoteProcedure(String host, int port, Object obj) {

        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;
        Object respObj = null;
        try {
            Socket socket = new Socket(host, port);
            oos = new ObjectOutputStream(socket.getOutputStream());
            oos.writeObject(obj);
            oos.flush();
            ois = new ObjectInputStream(socket.getInputStream());
            respObj = ois.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (ois != null) {
                try {
                    ois.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return respObj;
    }
}
