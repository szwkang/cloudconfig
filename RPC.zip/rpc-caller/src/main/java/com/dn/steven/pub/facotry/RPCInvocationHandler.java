package com.dn.steven.pub.facotry;

import com.dn.steven.pub.api.ServiceMapped;
import com.dn.steven.pub.dto.RPCTransformObj;
import com.dn.steven.pub.net.BIOClient;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class RPCInvocationHandler implements InvocationHandler {

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        //网络通讯的细节是不是应该写在这里..???
        //构建这个对象
        RPCTransformObj rpcTransformObj= new RPCTransformObj();
        rpcTransformObj.setMethodName(method.getName());
        rpcTransformObj.setParmas(args);

        Class<?> clazz =method.getDeclaringClass();
        String  classpath = clazz.getDeclaredAnnotation(ServiceMapped.class).value();

        rpcTransformObj.setClassPath(classpath);

        //发起网络请求完成远程服务调用..
        return BIOClient.callRemoteProcedure("localhost",8888,rpcTransformObj);
    }
}
