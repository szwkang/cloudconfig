package com.dn.steven.pub;

import com.dn.steven.pub.api.UserService;
import com.dn.steven.pub.dto.UserDTO;
import com.dn.steven.pub.facotry.ProxyFactory;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

        UserService userService = ProxyFactory.getServiceByClass(UserService.class);
        UserDTO userDTO=new UserDTO();
        userDTO.setName("steven");
        userDTO.setAge(18);
        System.out.println("调用前"+userDTO);
        userDTO=userService.addUser(userDTO);
        System.out.println("调用后"+userDTO);
    }
}
