package com.dn.steven.pub.facotry;

import com.dn.steven.pub.api.UserService;

import java.lang.reflect.Proxy;

/**
 * 勿在浮沙建高楼,万丈高楼平地起
 * Author : Steven
 */
public class ProxyFactory {


    public static <T>T getServiceByClass(Class<T> clazz){

        return (T) Proxy.newProxyInstance(ProxyFactory.class.getClassLoader(),
                new Class[]{
                        clazz
                },new RPCInvocationHandler());

    }


}
